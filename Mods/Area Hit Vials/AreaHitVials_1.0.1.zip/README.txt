Area Hit Vials 1.0.1 (Virtunerd) - Kingdom Come: Deliverance II

Throw potions, poisons and spirits as vials. The vial shatters on impact and everyone
within the radius gets exactly what drinking it would do - including poisons mixed in
with The Poisoner. Nobody notices who threw it.

Controls
  Hold Ctrl        radial menu: point at a vial with the mouse, release Ctrl to pick it
                   (mouse wheel or the small arrows: more pages, arrows at the top: other mods)
  Hold E           (looking at nothing) shows the picked vial, release E to throw it
  Mouse wheel      while holding E: change the vial
  E + right mouse  cancel the throw
When the game offers an action on E in front of you (pick up, steal, open, talk),
E belongs to the game and nothing is thrown.
Standing or crouched does not matter. Texts follow the game language (German or English).

Install
  1. Copy the folder Mods\area_hit_vials into <game>\Mods (or install the zip with Vortex).
  2. Optional, for poisons inside potions: copy Bin\Win64MasterMasterSteamPGO\AreaHitVials.asi
     into <game>\Bin\Win64MasterMasterSteamPGO. An ASI loader is required there
     (e.g. Ultimate ASI Loader as dinput8.dll). Without it, potions splash without their poisons.

Optional: Virtunerd Radial (separate mod). If it is installed, its radial menu is used and
Area Hit Vials adds its Vials tab there; without it Area Hit Vials uses its own built-in menu.

Settings in Mods\area_hit_vials\mod.cfg: radius, throw speed and lift, vial lifetime,
radial menu on/off, throw display on/off.
