Virtunerd Radial 1.0.1 (Virtunerd) - Kingdom Come: Deliverance II

A radial menu other mods can plug into. Hold Ctrl: a ring opens in the middle of the screen,
point at an entry with the mouse and release Ctrl to use it. The arrows at the top switch
between the mods that add a tab, the mouse wheel or the small arrows below turn pages.
Controls and camera pause while the ring is open. While E is held for an action the
game offers in front of you (pick up, steal, open, talk), the ring stays closed.

On its own it shows nothing; mods such as Area Hit Vials add their tabs. Area Hit Vials works
with or without it (it then uses this ring instead of its built-in one).

Install: copy the folder Mods\virtunerd_radial into <game>\Mods (or install the zip with Vortex).
