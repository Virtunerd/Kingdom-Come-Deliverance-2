Reflex Throw 1.0.0 by Virtunerd - Kingdom Come: Deliverance II

While Henry carries a body (dead or unconscious) over his shoulder:
  Tap E            - throw the body far in the direction you are looking.
                     It leaves his shoulder at once, no put-down animation.
  B, 1-4 (pad: X)  - the body drops straight from the shoulder, then the key does what it does in vanilla
                     (1-4 take the weapon from that quick slot, B draws/sheathes) - quick slots stay as they are.
  Hold E           - put the body down as usual (vanilla).
While carrying, a "Throw" button hint is shown next to the vanilla "Put down".

Install
  Mods\reflexthrow                                -> into the game's Mods folder (or install the zip with Vortex)
  Bin\Win64MasterMasterSteamPGO\ReflexThrow.asi  -> into the game's Bin\Win64MasterMasterSteamPGO folder
  Needs an ASI loader (e.g. Ultimate ASI Loader as dinput8.dll). The ASI only does something while
  Mods\reflexthrow is installed; without the ASI the mod does nothing.

Compatibility
  Replaces Libs/Config/defaultActionHelp.xml (button hints). Other mods that replace this file
  can hide the "Throw" hint; throwing itself still works.
  Built for KCD2 (Steam, October 2026). After a game update the ASI may not find its spot - it then
  changes nothing and the mod stays inactive.
